public class ClientNonAutoriseException extends RuntimeException {
    public ClientNonAutoriseException(String message)
    {
        super(message);
    }
}