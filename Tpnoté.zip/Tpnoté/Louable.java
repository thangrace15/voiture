public interface Louable {
    void louer();  // Louer le véhicule
    void retourner();  // Retourner le véhicule
}